"""CodiAI local assistant."""
__version__ = "0.1.1"
